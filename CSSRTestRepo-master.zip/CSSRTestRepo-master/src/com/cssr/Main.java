package com.cssr;

public class Main {

    public static void main(String[] args) {

        System.out.println("Hello World!");
        System.out.println("Hi, Im Ray!");
        System.out.println("Hey, CSSR team help me write some code.");
        System.out.println("Wazam, it's datboi Lee-Roy");
    }
}
